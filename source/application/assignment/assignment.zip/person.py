
class Person:
    def __init__(self,name,userid,phone,card):
        self.name = name
        self.userid = userid
        self.phone = phone
        self.card = card

