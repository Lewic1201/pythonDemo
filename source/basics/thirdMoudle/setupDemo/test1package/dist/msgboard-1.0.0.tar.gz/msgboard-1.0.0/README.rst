README.rst
========================
message board
========================

- a simple message board
- execute command "msgboard" in cmd